import test from 'node:test';
import assert from 'node:assert/strict';
import { analyzeDeck, formatDeckAnalysis, matchupHints } from '../src/strategy.js';

test('identifica condição de vitória, estrutura e custo médio', () => {
  const catalog = [
    { name: 'Hog Rider', elixirCost: 4 }, { name: 'Musketeer', elixirCost: 4 },
    { name: 'Cannon', elixirCost: 3 }, { name: 'Fireball', elixirCost: 4 },
    { name: 'The Log', elixirCost: 2 }, { name: 'Ice Golem', elixirCost: 2 },
    { name: 'Skeletons', elixirCost: 1 }, { name: 'Ice Spirit', elixirCost: 1 },
  ];
  const result = analyzeDeck(catalog.map((c) => c.name), catalog);
  assert.deepEqual(result.winConditions, ['Hog Rider']);
  assert.equal(result.avgElixir, 2.625);
  assert.ok(result.strengths.some((s) => s.includes('Musketeer')));
  assert.ok(formatDeckAnalysis(result).includes('Hog Rider'));
});

test('sugere resposta conhecida a Hog Rider e alerta de defesa aérea', () => {
  const result = matchupHints(
    ['Cannon', 'The Log', 'Valkyrie', 'Knight'],
    ['Hog Rider', 'Balloon', 'Fireball', 'Zap'],
  );
  assert.ok(result.answers.find((x) => x.threat === 'Hog Rider').answers.includes('Cannon'));
  assert.ok(result.warnings.some((x) => x.includes('defesa aérea')));
});

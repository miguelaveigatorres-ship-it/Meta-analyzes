import test from "node:test";
import assert from "node:assert/strict";
import { commands } from "../src/commands.js";

const EXPECTED = ["perfil","deck","meta","atualizacoes","torneios","torneio","perguntar","plano","matchup","atualizar"];

test("todos os 10 comandos existem pela ordem original", () => {
  assert.deepEqual(commands.map((c) => c.name), EXPECTED);
});

for (const cmd of commands) {
  test(`/${cmd.name}: opções obrigatórias antes das opcionais`, () => {
    const opts = cmd.options ?? [];
    const firstOptional = opts.findIndex((o) => !o.required);
    if (firstOptional === -1) return;
    assert.ok(opts.slice(firstOptional).every((o) => !o.required),
      `ordem inválida: ${opts.map((o) => `${o.name}${o.required ? "*" : ""}`).join(", ")}`);
  });
  test(`/${cmd.name}: limites do Discord`, () => {
    assert.match(cmd.name, /^[\p{Ll}\p{N}_-]{1,32}$/u);
    assert.ok(cmd.description.length >= 1 && cmd.description.length <= 100);
    for (const o of cmd.options ?? []) {
      assert.match(o.name, /^[\p{Ll}\p{N}_-]{1,32}$/u);
      assert.ok(o.description.length <= 100);
      assert.ok((o.choices?.length ?? 0) <= 25);
    }
  });
}

test("/plano e /matchup mantêm tag, adversario (obrigatórias) e modo (opcional)", () => {
  for (const n of ["plano", "matchup"]) {
    const o = commands.find((c) => c.name === n).options;
    assert.deepEqual(o.map((x) => [x.name, !!x.required]), [["tag", true], ["adversario", true], ["modo", false]]);
  }
});

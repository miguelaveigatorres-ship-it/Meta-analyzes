# Clash Royale Competitive Coach — Discloud 100 MB

Versão de desenvolvimento otimizada para alojamento com 100 MB de RAM. Não substitui automaticamente a publicação atual.

## Configuração no painel Discloud

Define as variáveis no painel (não coloques chaves reais no ZIP):

- `DISCORD_TOKEN` e `DISCORD_CLIENT_ID`
- `CR_API_TOKEN`
- `AI_GATEWAY_API_KEY`
- `AI_GATEWAY_MODEL` (opcional; predefinição `google/gemini-2.5-flash`)
- `SUPABASE_URL` e `SUPABASE_SERVICE_ROLE_KEY` (opcionais para persistir snapshots do meta)
- `META_TOP_PLAYERS=25` (máximo aceite: 40)
- `META_REFRESH_MINUTES=360` (mínimo aceite: 60)
- `NODE_OPTIONS=--max-old-space-size=64` (define no painel da Discloud, antes do arranque; não basta pôr no ficheiro `.env`)

O `discloud.config` mantém `RAM=100`. Define também `NODE_OPTIONS=--max-old-space-size=64` nas variáveis de ambiente do painel da Discloud para limitar o heap V8. O limite do heap não representa a RAM total do processo; o Discord.js, buffers e memória nativa também consomem recursos. O script `npm start` já inclui esse limite para testes locais.

## Otimizações para 100 MB

- Cache do Discord.js limitada: mensagens, presenças e membros não ficam guardados em cache.
- Conversas Gemini limitadas a 100 sessões, 4 trocas por sessão, 2 horas de validade e 2 pedidos de IA simultâneos.
- Mensagens do chat limitadas a 1400 caracteres.
- Meta recolhido de 25 jogadores por defeito, até 40, com intervalo de 6 horas por defeito.
- Cada histórico de batalhas é limitado às 25 batalhas mais recentes.
- Persistência Supabase via REST nativa, sem carregar o SDK JavaScript.
- Uma recolha vazia não apaga um meta anterior válido.

## Treinador competitivo

- `/deck`: recomenda um arquétipo observado no meta e apresenta uma análise estrutural do deck (condição de vitória, feitiços, defesa aérea, edifícios e custo médio).
- `/matchup`: compara o deck recomendado com as 8 cartas do adversário e apresenta respostas conhecidas e alertas de confronto.
- `/plano`: acrescenta essas pistas locais ao contexto enviado ao Gemini para gerar um plano estratégico.
- As relações de counters são heurísticas: posicionamento, níveis, evoluções e ciclo podem alterar o resultado. Não são previsões garantidas de vitória.

## Chat livre

Menciona o bot num canal ou numa mensagem privada. Para apagar contexto: `@Coach limpar conversa`.

No Discord Developer Portal, ativa **Message Content Intent**.

## Comandos preservados

`/perfil`, `/deck`, `/meta`, `/atualizacoes`, `/torneios`, `/torneio`, `/perguntar`, `/plano`, `/matchup`, `/atualizar`.

## Instalação e teste

1. Extrai o ZIP.
2. Entra na pasta `bot`.
3. Executa `npm ci`.
4. Executa `npm run check`.
5. Configura as variáveis no ambiente de teste.
6. Testa primeiro num bot/servidor Discord de desenvolvimento.
7. Só depois de validar, prepara a substituição na Discloud.

Não publiques esta versão por cima do bot atual antes dos testes.

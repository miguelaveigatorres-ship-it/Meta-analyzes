import { SlashCommandBuilder } from "discord.js";

export const MODE_CHOICES = [
  { name: "Ladder / Path of Legends", value: "ladder" },
  { name: "Desafio Clássico", value: "classico" },
  { name: "Desafio das 20 Wins", value: "20wins" },
  { name: "Outros desafios", value: "desafio" },
  { name: "2x2", value: "2x2" },
];
export const MODE_LABELS = Object.fromEntries(MODE_CHOICES.map((m) => [m.value, m.name]));

const tagOption = (o) => o.setName("tag").setDescription("Tag do jogador, ex: #ABC123").setRequired(true);
const modeOption = (o) => o.setName("modo").setDescription("Modo de jogo (por defeito: Ladder)").addChoices(...MODE_CHOICES);

export const commands = [
  new SlashCommandBuilder().setName("perfil").setDescription("Mostra as cartas mais fortes de um jogador")
    .addStringOption(tagOption),
  new SlashCommandBuilder().setName("deck").setDescription("Cria um deck com as tuas cartas mais fortes e mede a adaptação ao meta")
    .addStringOption(tagOption).addStringOption(modeOption),
  new SlashCommandBuilder().setName("meta").setDescription("Top decks do meta atual")
    .addStringOption(modeOption),
  new SlashCommandBuilder().setName("atualizacoes").setDescription("Mostra as mudanças do meta num mês")
    .addStringOption((o) => o.setName("mes").setDescription("Mês no formato AAAA-MM (vazio = mês atual)")),
  new SlashCommandBuilder().setName("torneios").setDescription("Torneios globais ativos e as suas recompensas"),
  new SlashCommandBuilder().setName("torneio").setDescription("Procura torneios pelo nome ou pela #tag")
    .addStringOption((o) => o.setName("pesquisa").setDescription("Nome ou #tag do torneio").setRequired(true)),
  new SlashCommandBuilder().setName("perguntar").setDescription("Faz uma pergunta estratégica sobre um torneio")
    .addStringOption(tagOption)
    .addStringOption((o) => o.setName("torneio").setDescription("Nome ou #tag do torneio").setRequired(true))
    .addStringOption((o) => o.setName("pergunta").setDescription("A tua pergunta (máx. 300 caracteres)").setRequired(true).setMaxLength(300)),
  new SlashCommandBuilder().setName("plano").setDescription("Plano de jogo contra o deck de um adversário")
    .addStringOption(tagOption)
    .addStringOption((o) => o.setName("adversario").setDescription("As 8 cartas do adversário, separadas por vírgulas").setRequired(true))
    .addStringOption(modeOption),
  new SlashCommandBuilder().setName("matchup").setDescription("Analisa o confronto entre o teu deck recomendado e um adversário")
    .addStringOption(tagOption)
    .addStringOption((o) => o.setName("adversario").setDescription("As 8 cartas do adversário, separadas por vírgulas").setRequired(true))
    .addStringOption(modeOption),
  new SlashCommandBuilder().setName("atualizar").setDescription("Força a atualização do meta"),
].map((c) => c.toJSON());

import "dotenv/config";
import { Client, Events, GatewayIntentBits, Options, Partials, REST, Routes } from "discord.js";
import { commands } from "./commands.js";
import { handleInteraction } from "./handlers.js";
import { cleanupChatHistory, handleChatMessage } from "./chat.js";
import { getMeta, initMeta, refreshMeta } from "./meta.js";

const REFRESH_MINUTES = Math.max(60, Number(process.env.META_REFRESH_MINUTES) || 360);
const REFRESH_MS = REFRESH_MINUTES * 60_000;

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.MessageContent,
  ],
  partials: [Partials.Channel],
  // Em 100 MB, não manter mensagens, presenças e membros completos em cache.
  makeCache: Options.cacheWithLimits({
    MessageManager: 0,
    PresenceManager: 0,
    GuildMemberManager: 0,
    ThreadMemberManager: 0,
    VoiceStateManager: 0,
  }),
  sweepers: {
    messages: { interval: 120, lifetime: 60 },
  },
});
client.on(Events.InteractionCreate, handleInteraction);
client.on(Events.MessageCreate, (message) => {
  handleChatMessage(message, client).catch((err) => console.error("[mensagem]", err?.message ?? err));
});

client.once(Events.ClientReady, async (c) => {
  console.log("Online como", c.user.tag);
  try {
    await new REST({ version: "10" })
      .setToken(process.env.DISCORD_TOKEN)
      .put(Routes.applicationCommands(process.env.DISCORD_CLIENT_ID), { body: commands });
    console.log("Comandos registados");
  } catch (err) {
    console.error("[comandos]", err.message);
  }
  try {
    await initMeta();
  } catch (err) {
    console.error("[meta inicial]", err.message);
  }
  if (!getMeta().updatedAt) refreshMeta().catch((e) => console.error("[meta]", e.message));
  setInterval(() => refreshMeta().catch((e) => console.error("[meta]", e.message)), REFRESH_MS);
  setInterval(cleanupChatHistory, 15 * 60_000);
  setInterval(() => {
    const { rss, heapUsed } = process.memoryUsage();
    console.log(`[memória] RSS ${(rss / 1024 / 1024).toFixed(1)} MB · heap ${(heapUsed / 1024 / 1024).toFixed(1)} MB`);
  }, 15 * 60_000).unref();
});

client.login(process.env.DISCORD_TOKEN);

import { realLevel } from "./cr.js";
import { getMeta } from "./meta.js";

const DECK_SIZE = 8;
const USAGE_TOP = 20;
const SCORE_TOP = 60;

export function ownedCards(player) {
  return (player.cards ?? []).map((c) => ({ name: c.name, lvl: realLevel(c), evo: (c.evolutionLevel ?? 0) > 0 }));
}

export function strongestCards(player, n) {
  return ownedCards(player)
    .sort((a, b) => b.lvl - a.lvl || Number(b.evo) - Number(a.evo))
    .slice(0, n);
}

// Quanto cada carta pesa nos decks do meta (0 a 1)
function cardUsage(decks) {
  const usage = {};
  for (const d of decks.slice(0, USAGE_TOP)) {
    for (const c of d.cards) usage[c.name] = (usage[c.name] ?? 0) + d.score;
  }
  const max = Math.max(1e-9, ...Object.values(usage));
  for (const name of Object.keys(usage)) usage[name] /= max;
  return usage;
}

// Adaptação ao meta de 0 a 100: sobreposição com um deck do meta, ponderada pela força desse deck
export function scoreDeck(names, decks) {
  const top = decks[0]?.score || 1;
  let best = { value: 0, closest: null };
  for (const d of decks.slice(0, SCORE_TOP)) {
    const shared = d.cards.filter((c) => names.includes(c.name)).length;
    const value = (shared / DECK_SIZE) * (0.6 + 0.4 * (d.score / top));
    if (value > best.value) best = { value, closest: d };
  }
  return { fit: Math.round(best.value * 100), closest: best.closest };
}

function collectionReadiness(deck, ownedByName) {
  const present = deck.cards.map((c) => ownedByName.get(c.name)).filter(Boolean);
  const coverage = present.length / DECK_SIZE;
  const level = present.length
    ? present.reduce((sum, c) => sum + Math.min(16, c.lvl) / 16, 0) / present.length
    : 0;
  const evolutions = present.filter((c) => c.evo).length / DECK_SIZE;
  return Math.round((coverage * 0.65 + level * 0.25 + evolutions * 0.10) * 100);
}

export function buildPlayerDeck(player, mode) {
  const decks = getMeta().decks[mode] ?? [];
  const owned = ownedCards(player);
  const ownedByName = new Map(owned.map((c) => [c.name, c]));
  const usage = cardUsage(decks);

  // Parte de um arquétipo real observado no meta em vez de juntar simplesmente
  // as oito cartas com maior nível, o que costuma produzir decks sem sinergia.
  const templates = decks.slice(0, SCORE_TOP)
    .map((d) => ({ deck: d, readiness: collectionReadiness(d, ownedByName) }))
    .sort((a, b) => b.readiness - a.readiness || b.deck.score - a.deck.score);
  const template = templates[0]?.deck;

  if (!template || collectionReadiness(template, ownedByName) < 35) {
    const cards = owned
      .map((c) => ({ ...c, power: 0.55 * (c.lvl / 16) + 0.3 * (usage[c.name] ?? 0) + 0.15 * Number(c.evo) }))
      .sort((a, b) => b.power - a.power)
      .slice(0, DECK_SIZE)
      .map(({ name, lvl, evo }) => ({ name, lvl, evo }));
    return { cards, fit: scoreDeck(cards.map((c) => c.name), decks).fit, method: "cartas mais fortes disponíveis" };
  }

  const selected = [];
  const selectedNames = new Set();
  for (const card of template.cards) {
    const ownedCard = ownedByName.get(card.name);
    if (ownedCard) {
      selected.push(ownedCard);
      selectedNames.add(ownedCard.name);
    }
  }

  const replacements = owned
    .filter((c) => !selectedNames.has(c.name))
    .map((c) => ({ ...c, power: 0.55 * (c.lvl / 16) + 0.3 * (usage[c.name] ?? 0) + 0.15 * Number(c.evo) }))
    .sort((a, b) => b.power - a.power);

  for (const card of replacements) {
    if (selected.length >= DECK_SIZE) break;
    selected.push(card);
  }

  const cards = selected.slice(0, DECK_SIZE).map(({ name, lvl, evo }) => ({ name, lvl, evo }));
  return {
    cards,
    fit: scoreDeck(cards.map((c) => c.name), decks).fit,
    method: `baseado no arquétipo ${template.cards.map((c) => c.name).slice(0, 2).join(" + ")}`,
  };
}

// Decks do meta que o jogador consegue montar (no máximo 2 cartas em falta)
export function playableMetaDecks(player, mode, n = 3) {
  const ownedByName = new Map(ownedCards(player).map((c) => [c.name, c]));
  const decks = getMeta().decks[mode] ?? [];
  return decks
    .map((d) => {
      const missing = d.cards.filter((c) => !ownedByName.has(c.name)).map((c) => c.name);
      return { ...d, missing, fit: collectionReadiness(d, ownedByName) };
    })
    .filter((d) => d.missing.length <= 2)
    .sort((a, b) => b.fit - a.fit || b.score - a.score)
    .slice(0, n);
}

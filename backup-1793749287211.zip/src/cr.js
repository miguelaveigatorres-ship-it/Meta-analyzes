// Cliente da API oficial do Clash Royale via proxy gratuito do RoyaleAPI
// (o proxy tem IP fixo, por isso funciona em alojamento sem IP fixo)
const BASE = "https://proxy.royaleapi.dev/v1";
const sleep = (ms) => new Promise((s) => setTimeout(s, ms));

export const cleanTag = (t) => t.trim().toUpperCase().replace(/^#/, "").replace(/O/g, "0");

async function get(path, retries = 3) {
  const r = await fetch(BASE + path, {
    headers: { Authorization: `Bearer ${process.env.CR_API_TOKEN}` },
    signal: AbortSignal.timeout(15_000),
  });
  if (r.status === 429 && retries > 0) { await sleep(2000); return get(path, retries - 1); }
  if (r.status === 404) throw new Error("Não encontrado na API do Clash Royale. Confirma a tag.");
  if (r.status === 400) throw new Error("Pedido inválido à API do Clash Royale.");
  if (!r.ok) throw new Error(`API do Clash Royale respondeu ${r.status}`);
  return r.json();
}

export const getPlayer = (tag) => get(`/players/%23${cleanTag(tag)}`);
export const getBattleLog = (tag) => get(`/players/%23${cleanTag(tag)}/battlelog`);
export const getTopPlayers = async (limit) =>
  (await get(`/locations/global/pathoflegend/players?limit=${limit}`)).items ?? [];

let cardCache = null;
export async function getCards() {
  cardCache ??= (await get("/cards")).items ?? [];
  return cardCache;
}

// Nível "real" (1-16) independente da raridade
export const realLevel = (c) => c.level + (16 - (c.maxLevel ?? 16));

export function classifyMode(type = "", title = "") {
  const t = type.toLowerCase();
  const n = title.toLowerCase();
  if (t.includes("2v2") || n.includes("2v2")) return "2x2";
  if (t === "pvp" || t === "pathoflegend" || n.includes("ladder")) return "ladder";
  if (t.includes("challenge") || n.includes("challenge")) {
    if (t === "grandchallenge" || n.includes("grand") || n.includes("20")) return "20wins";
    if (n.includes("classic") || n.includes("clássico")) return "classico";
    return "desafio";
  }
  return null;
}

export const modeOf = (b) => classifyMode(b.type, b.challengeTitle || b.gameMode?.name || "");

export const getGlobalTournaments = async () => (await get("/globaltournaments")).items ?? [];
export const searchTournaments = async (name) => (await get(`/tournaments?name=${encodeURIComponent(name)}&limit=10`)).items ?? [];
export const getTournament = (tag) => get(`/tournaments/%23${cleanTag(tag)}`);

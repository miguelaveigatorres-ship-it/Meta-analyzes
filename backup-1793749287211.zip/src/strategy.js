// Avaliação estratégica local: não depende de pedidos Gemini nem de mais RAM.
// As listas são heurísticas conservadoras; não substituem análise de replay.
const WIN_CONDITIONS = new Set([
  "Hog Rider", "Royal Giant", "Giant", "Goblin Giant", "Golem", "Lava Hound",
  "Electro Giant", "Ram Rider", "Battle Ram", "Wall Breakers", "Miner", "Mortar",
  "X-Bow", "Graveyard", "Goblin Drill", "Goblin Barrel", "Royal Hogs", "Skeleton Barrel", "Three Musketeers", "Balloon",
]);
const SMALL_SPELLS = new Set(["The Log", "Zap", "Giant Snowball", "Arrows", "Barbarian Barrel", "Tornado"]);
const BIG_SPELLS = new Set(["Fireball", "Poison", "Rocket", "Lightning", "Earthquake"]);
const BUILDINGS = new Set(["Cannon", "Tesla", "Inferno Tower", "Bomb Tower", "Goblin Cage", "Tombstone", "Mortar", "X-Bow", "Furnace"]);
const AIR_DEFENSE = new Set([
  "Musketeer", "Archers", "Firecracker", "Hunter", "Inferno Dragon", "Baby Dragon",
  "Mega Minion", "Minions", "Minion Horde", "Phoenix", "Electro Wizard", "Wizard",
  "Executioner", "Flying Machine", "Tesla", "Inferno Tower", "Bats", "Dart Goblin",
]);
const SWARM = new Set(["Skeleton Army", "Goblin Gang", "Minion Horde", "Minions", "Bats", "Guards", "Skeletons", "Goblins", "Barbarians"]);
const RESET_OR_CONTROL = new Set(["Zap", "Electro Wizard", "Electro Spirit", "Lightning", "Freeze", "The Log", "Giant Snowball"]);

// Relações conhecidas e úteis para orientação; só são apresentadas como pistas,
// nunca como garantias de counter universal.
const COUNTERS = {
  "Hog Rider": ["Cannon", "Tesla", "Bomb Tower", "Tornado", "Goblin Cage"],
  "Balloon": ["Musketeer", "Tesla", "Inferno Tower", "Hunter", "Firecracker", "Minions"],
  "Mega Knight": ["P.E.K.K.A", "Mini P.E.K.K.A", "Knight", "Valkyrie", "Inferno Tower", "Inferno Dragon"],
  "Golem": ["Inferno Tower", "Inferno Dragon", "P.E.K.K.A", "Mini P.E.K.K.A", "Cannon Cart"],
  "Royal Giant": ["Inferno Tower", "P.E.K.K.A", "Mini P.E.K.K.A", "Fisherman", "Goblin Cage"],
  "Graveyard": ["Poison", "Valkyrie", "Knight", "Baby Dragon", "Archers", "Skeleton King"],
  "Goblin Barrel": ["The Log", "Barbarian Barrel", "Arrows", "Goblin Gang", "Guards"],
  "Lava Hound": ["Musketeer", "Inferno Dragon", "Minions", "Mega Minion", "Executioner", "Firecracker"],
  "X-Bow": ["Rocket", "Earthquake", "Lightning", "Royal Giant", "Golem", "Giant"],
  "Mortar": ["Earthquake", "Rocket", "Miner", "Royal Giant", "Golem"],
  "P.E.K.K.A": ["Skeletons", "Bats", "Minions", "Goblin Gang", "Ice Golem"],
};

const unique = (arr) => [...new Set(arr)];

export function analyzeDeck(names, cardCatalog = []) {
  const cards = names.map((name) => cardCatalog.find((c) => c.name === name)).filter(Boolean);
  const avgElixir = cards.length
    ? cards.reduce((sum, c) => sum + (Number(c.elixirCost) || 0), 0) / cards.length
    : null;
  const winConditions = names.filter((n) => WIN_CONDITIONS.has(n));
  const smallSpells = names.filter((n) => SMALL_SPELLS.has(n));
  const bigSpells = names.filter((n) => BIG_SPELLS.has(n));
  const buildings = names.filter((n) => BUILDINGS.has(n));
  const airDefense = names.filter((n) => AIR_DEFENSE.has(n));
  const swarm = names.filter((n) => SWARM.has(n));
  const reset = names.filter((n) => RESET_OR_CONTROL.has(n));
  const issues = [];
  const strengths = [];
  if (!winConditions.length) issues.push("Não foi identificada uma condição de vitória clara.");
  else if (winConditions.length > 2) issues.push("Há várias condições de vitória; pode faltar suporte consistente a cada uma.");
  else strengths.push(`Condição(ões) de vitória: ${winConditions.join(", ")}.`);
  if (!smallSpells.length) issues.push("Não foi identificado um feitiço pequeno para limpar tropas frágeis ou reiniciar cargas.");
  if (!bigSpells.length) issues.push("Não foi identificado um feitiço pesado para remover suporte ou pressionar tropas/torres.");
  if (!airDefense.length) issues.push("Defesa antiaérea potencialmente fraca: confirma se consegues responder a Balão e Lava Hound.");
  else strengths.push(`Respostas antiaéreas identificadas: ${airDefense.slice(0, 4).join(", ")}.`);
  if (buildings.length) strengths.push(`Estrutura defensiva: ${buildings.join(", ")}.`);
  if (swarm.length >= 3) issues.push("Muitas tropas de enxame: cuidado com Tronco, Flechas, Veneno e dano em área.");
  if (avgElixir !== null && avgElixir > 4.2) issues.push(`Custo médio elevado (${avgElixir.toFixed(1)}): risco de ciclo lento e punição na outra faixa.`);
  if (avgElixir !== null && avgElixir < 2.6) issues.push(`Custo médio muito baixo (${avgElixir.toFixed(1)}): confirma se tens dano suficiente para defender pushes pesados.`);
  if (reset.length) strengths.push(`Reset/controlo: ${reset.join(", ")}.`);
  if (avgElixir !== null && avgElixir >= 2.8 && avgElixir <= 4.0) strengths.push(`Custo médio equilibrado: ${avgElixir.toFixed(1)} de elixir.`);
  return { avgElixir, winConditions, smallSpells, bigSpells, buildings, airDefense, swarm, issues, strengths };
}

export function matchupHints(ownNames, enemyNames) {
  const own = new Set(ownNames);
  const threats = enemyNames.filter((n) => WIN_CONDITIONS.has(n));
  const answers = [];
  for (const threat of threats) {
    const available = (COUNTERS[threat] ?? []).filter((n) => own.has(n));
    answers.push({ threat, answers: available });
  }
  const enemyHasSmallSpell = enemyNames.some((n) => SMALL_SPELLS.has(n));
  const ownSwarm = ownNames.filter((n) => SWARM.has(n));
  const warnings = [];
  if (ownSwarm.length && enemyHasSmallSpell) warnings.push(`O adversário tem feitiço pequeno; evita oferecer ${ownSwarm.join(", ")} juntos.`);
  const ownAnalysis = analyzeDeck(ownNames);
  if (!ownAnalysis.airDefense.length && enemyNames.some((n) => ["Balloon", "Lava Hound", "Minion Horde"].includes(n))) {
    warnings.push("A tua defesa aérea parece limitada contra a ameaça aérea identificada.");
  }
  return { threats, answers, warnings };
}

export function formatDeckAnalysis(a) {
  const lines = [];
  if (a.avgElixir !== null) lines.push(`Elixir médio aproximado: ${a.avgElixir.toFixed(1)}.`);
  if (a.strengths.length) lines.push(`Pontos fortes: ${a.strengths.join(" ")}`);
  if (a.issues.length) lines.push(`A verificar: ${a.issues.join(" ")}`);
  return lines.join("\n").slice(0, 1800) || "Análise estrutural limitada: confirma as funções das cartas e testa o deck em batalha.";
}

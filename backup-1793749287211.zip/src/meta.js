// Recolhe batalhas dos melhores jogadores e calcula a taxa de vitória de cada deck por modo.
import { getTopPlayers, getBattleLog, modeOf } from "./cr.js";
import { loadLatestSnapshots, saveSnapshot } from "./store.js";

export const MODES = ["ladder", "classico", "20wins", "desafio", "2x2"];
const DECK_SIZE = 8;
const SCORE_TOP = 60;

let state = { updatedAt: null, decks: {} };
let inFlight = null;

export const getMeta = () => state;
export const currentMonth = () => new Date().toISOString().slice(0, 7);

export async function initMeta() {
  state = await loadLatestSnapshots();
}

const sleep = (ms) => new Promise((s) => setTimeout(s, ms));

async function collectDecks(topN) {
  const players = await getTopPlayers(topN);
  const stats = {};
  const seen = new Set();
  for (const p of players) {
    let log;
    try { log = await getBattleLog(p.tag); } catch { continue; }
    for (const b of log.slice(0, 25)) {
      const mode = modeOf(b);
      if (!mode) continue;
      const me = b.team?.[0];
      const op = b.opponent?.[0];
      if (!me?.cards || me.cards.length < DECK_SIZE) continue;
      const battleId = `${b.battleTime}|${[me.tag, op?.tag].sort().join("|")}`;
      if (seen.has(battleId)) continue;
      seen.add(battleId);
      const win = (me.crowns ?? 0) > (op?.crowns ?? 0);
      const key = me.cards.map((c) => c.name).sort().join("|");
      const bucket = (stats[mode] ??= {});
      const d = (bucket[key] ??= {
        key,
        cards: me.cards.map((c) => ({ name: c.name, id: c.id, evo: (c.evolutionLevel ?? 0) > 0 })),
        w: 0,
        g: 0,
      });
      if (win) d.w += 1;
      d.g += 1;
    }
    await sleep(100);
  }
  const decks = {};
  for (const mode of MODES) {
    const list = Object.values(stats[mode] ?? {}).filter((d) => d.g >= 2);
    for (const d of list) d.score = (d.w + 5) / (d.g + 10);
    decks[mode] = list.sort((a, b) => b.score - a.score).slice(0, SCORE_TOP);
  }
  return decks;
}

async function doRefresh(topN) {
  console.log("[meta] a atualizar…");
  const decks = await collectDecks(topN);
  const total = Object.values(decks).reduce((sum, list) => sum + list.length, 0);
  if (total === 0 && state.updatedAt) {
    console.warn("[meta] recolha sem resultados; mantenho os dados anteriores.");
    return;
  }
  state = { updatedAt: new Date().toISOString(), decks };
  const month = currentMonth();
  await Promise.all(MODES.map((mode) => saveSnapshot(month, mode, decks[mode])));
  console.log("[meta] pronto:", MODES.map((m) => `${m}=${decks[m].length}`).join(" "));
}

export function refreshMeta() {
  const topN = Math.min(40, Math.max(10, Number(process.env.META_TOP_PLAYERS) || 25));
  inFlight ??= doRefresh(topN).finally(() => { inFlight = null; });
  return inFlight;
}

// Compara o top 5 de um mês com o mês anterior
export function monthlyChanges(prev, cur) {
  const prevRank = new Map(prev.map((d, i) => [d.key, i + 1]));
  const curRank = new Map(cur.map((d, i) => [d.key, i + 1]));
  const top = cur.slice(0, 5).map((deck, i) => {
    const rank = i + 1;
    const before = prevRank.get(deck.key);
    let status = "novo no top";
    if (before !== undefined) {
      if (before > rank) status = `subiu ${before - rank}`;
      else if (before < rank) status = `desceu ${rank - before}`;
      else status = "manteve a posição";
    }
    return { deck, rank, status };
  });
  const dropped = prev.slice(0, 5).filter((d) => !curRank.has(d.key) || curRank.get(d.key) > 10);
  return { top, dropped };
}

import { chatAI } from "./ai.js";

const MAX_HISTORY_MESSAGES = 8; // quatro trocas por jogador
const HISTORY_TTL_MS = 2 * 60 * 60 * 1000;
const MAX_SESSIONS = 100;
const MAX_PROMPT_CHARS = 1400;
const MAX_CONCURRENT_AI = 2;
const histories = new Map();
const busyUsers = new Set();
let activeAI = 0;

function conversationKey(message) {
  return `${message.guildId ?? "dm"}:${message.author.id}`;
}

function trimHistory(history) {
  if (history.length > MAX_HISTORY_MESSAGES) history.splice(0, history.length - MAX_HISTORY_MESSAGES);
}

function trimSessions(now = Date.now()) {
  for (const [key, session] of histories) {
    if (now - session.updatedAt > HISTORY_TTL_MS) histories.delete(key);
  }
  while (histories.size >= MAX_SESSIONS) {
    const oldest = histories.keys().next().value;
    if (!oldest) break;
    histories.delete(oldest);
  }
}

function splitDiscordMessage(text, limit = 1900) {
  const chunks = [];
  let remaining = String(text ?? "").trim();
  while (remaining.length > limit) {
    let cut = remaining.lastIndexOf("\n", limit);
    if (cut < limit * 0.5) cut = remaining.lastIndexOf(" ", limit);
    if (cut < limit * 0.5) cut = limit;
    chunks.push(remaining.slice(0, cut).trim());
    remaining = remaining.slice(cut).trim();
  }
  if (remaining) chunks.push(remaining);
  return chunks;
}

export async function handleChatMessage(message, client) {
  if (!message || message.author?.bot || !client.user) return;
  if (!message.mentions?.has(client.user)) return;

  const prompt = message.content.replace(new RegExp(`<@!?${client.user.id}>`, "g"), "").trim();
  if (!prompt) {
    await message.reply("Estou aqui! Faz a tua pergunta sobre Clash Royale. Podes também dizer-me a tua tag para contextualizar melhor as recomendações.");
    return;
  }

  const key = conversationKey(message);
  if (/^(limpar|limpa|reiniciar|resetar) (a )?(conversa|chat)$/i.test(prompt)) {
    histories.delete(key);
    await message.reply("Conversa reiniciada. Podemos começar do zero!");
    return;
  }
  if (prompt.length > MAX_PROMPT_CHARS) {
    await message.reply(`A tua mensagem é demasiado longa. Resume a pergunta para ${MAX_PROMPT_CHARS} caracteres ou menos.`);
    return;
  }
  if (busyUsers.has(key)) {
    await message.reply("Ainda estou a analisar a tua pergunta anterior. Dá-me só um momento.");
    return;
  }
  if (activeAI >= MAX_CONCURRENT_AI) {
    await message.reply("Neste momento estou a responder a outros jogadores. Tenta novamente dentro de alguns segundos.");
    return;
  }

  const now = Date.now();
  trimSessions(now);
  let session = histories.get(key);
  if (!session || now - session.updatedAt > HISTORY_TTL_MS) {
    session = { messages: [], updatedAt: now };
    histories.set(key, session);
  }

  busyUsers.add(key);
  activeAI += 1;
  try {
    await message.channel.sendTyping().catch(() => {});
    const nextMessages = [...session.messages, { role: "user", content: prompt }];
    const answer = await chatAI(nextMessages);
    if (!answer) {
      await message.reply("Não consegui contactar o meu motor de IA neste momento. Tenta novamente daqui a pouco.");
      return;
    }

    session.messages = [...nextMessages, { role: "assistant", content: answer }];
    trimHistory(session.messages);
    session.updatedAt = Date.now();
    histories.delete(key);
    histories.set(key, session); // mantém as sessões recentes no fim do Map

    const chunks = splitDiscordMessage(answer);
    if (chunks.length) {
      await message.reply(chunks[0]);
      for (const chunk of chunks.slice(1)) await message.channel.send(chunk);
    }
  } catch (err) {
    console.error("[chat]", err?.message ?? err);
    await message.reply("Ocorreu um erro ao preparar a resposta. Tenta novamente.").catch(() => {});
  } finally {
    busyUsers.delete(key);
    activeAI = Math.max(0, activeAI - 1);
  }
}

export function cleanupChatHistory() {
  trimSessions();
}

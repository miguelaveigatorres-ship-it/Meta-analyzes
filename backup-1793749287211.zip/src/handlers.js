import { EmbedBuilder } from "discord.js";
import { askAI } from "./ai.js";
import { MODE_LABELS } from "./commands.js";
import { buildPlayerDeck, playableMetaDecks, scoreDeck, strongestCards } from "./builder.js";
import { cardNames, fmtDeck, fmtReward, fmtTour, rewardsOf, shortDeck, tourName, winrate } from "./format.js";
import { getCards, getGlobalTournaments, getPlayer, getTournament, searchTournaments, classifyMode } from "./cr.js";
import { currentMonth, getMeta, MODES, monthlyChanges, refreshMeta } from "./meta.js";
import { loadMonthSnapshots } from "./store.js";
import { analyzeDeck, formatDeckAnalysis, matchupHints } from "./strategy.js";

const NO_META = "Ainda não há dados para este modo. Usa /atualizar para recolher o meta.";
const COLORS = { info: 0x3b82f6, meta: 0xf5b301, win: 0x22c55e, tour: 0xa855f7 };
const MONTH_RE = /^\d{4}-(0[1-9]|1[0-2])$/;

const normName = (s) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]/g, "");

const fieldValue = (text) => text.slice(0, 1024) || "-";

function previousMonth(month) {
  const [y, m] = month.split("-").map(Number);
  return new Date(Date.UTC(y, m - 2, 1)).toISOString().slice(0, 7);
}

async function resolveTournament(term) {
  const q = term.trim();
  if (q.startsWith("#")) return getTournament(q);
  if (q.length < 3) return null;
  const list = await searchTournaments(q);
  const active = list.find((t) => t.status !== "ended") ?? list[0];
  return active ? getTournament(active.tag) : null;
}

async function parseOpponentDeck(text) {
  const catalog = new Map((await getCards()).map((c) => [normName(c.name), c.name]));
  const names = [];
  const invalid = [];
  for (const part of text.split(/[,;\n]/).map((p) => p.trim()).filter(Boolean)) {
    const name = catalog.get(normName(part));
    if (!name) invalid.push(part);
    else if (names.includes(name)) invalid.push(`${part} (repetida)`);
    else names.push(name);
  }
  return { names, invalid };
}

async function perfil(i) {
  const player = await getPlayer(i.options.getString("tag"));
  const strong = strongestCards(player, 12);
  const e = new EmbedBuilder().setTitle(`${player.name} (${player.tag})`).setColor(COLORS.info)
    .setDescription(`🏆 ${player.trophies} · Arena: ${player.arena?.name ?? "?"}\n\n**Cartas mais fortes:**\n` +
      strong.map((c) => `${c.evo ? "✨" : "•"} ${c.name} – nível ${c.lvl}`).join("\n"));
  return i.editReply({ embeds: [e] });
}

const selectedMode = (i) => i.options.getString("modo") ?? "ladder";

async function deck(i) {
  const mode = selectedMode(i);
  const player = await getPlayer(i.options.getString("tag"));
  const decks = getMeta().decks[mode] ?? [];
  if (!decks.length) return i.editReply(NO_META);

  const mine = buildPlayerDeck(player, mode);
  const options = playableMetaDecks(player, mode, 3);
  const mineText = fieldValue(mine.cards.map((c) => `${c.evo ? "✨ " : ""}${c.name} (nível ${c.lvl})`).join("\n"));
  const deckAnalysis = formatDeckAnalysis(analyzeDeck(mine.cards.map((c) => c.name), await getCards()));
  const optionsText = fieldValue(options.length
    ? options.map((d, n) => `**${n + 1}.** ${cardNames(d).join(", ")}\nCompatibilidade com a coleção: **${d.fit}/100** · Winrate ${winrate(d).toFixed(0)}% (${d.g} jogos)` +
      (d.missing.length ? `\nFaltam: ${d.missing.join(", ")}` : "\nPronto a jogar")).join("\n\n")
    : "Nenhum deck do meta está perto das tuas cartas.");

  const ai = await askAI(`Modo: ${MODE_LABELS[mode]}. Jogador: ${player.name}, ${player.trophies} troféus.
Deck recomendado (${mine.method}; compatibilidade ${mine.fit}/100): ${mine.cards.map((c) => c.name).join(", ")}.
Decks do meta que o jogador pode jogar: ${options.map((d) => `${cardNames(d).join(", ")} (compatibilidade ${d.fit}/100)`).join(" || ") || "nenhum"}.
Em no máximo 3 frases, diz qual deve jogar e porquê.`);

  const e = new EmbedBuilder().setTitle(`Deck para ${player.name} · ${MODE_LABELS[mode]}`).setColor(COLORS.win)
    .addFields(
      { name: `Deck recomendado · ${mine.fit}/100`, value: fieldValue(`${mineText}\n\n_Seleção: ${mine.method}._\n\n**Análise estrutural**\n${deckAnalysis}`) },
      { name: "Decks do meta que podes jogar", value: optionsText },
      { name: "Recomendação", value: fieldValue(ai ?? "A IA não respondeu de momento. Usa os decks acima.") },
    );
  return i.editReply({ embeds: [e] });
}

async function meta(i) {
  const mode = selectedMode(i);
  const list = (getMeta().decks[mode] ?? []).slice(0, 5);
  if (!list.length) return i.editReply(NO_META);
  const e = new EmbedBuilder().setTitle(`Meta · ${MODE_LABELS[mode]}`).setColor(COLORS.meta)
    .setDescription(list.map((d, n) => `**${n + 1}.** ${fmtDeck(d)}`).join("\n\n"))
    .setFooter({ text: `Atualizado: ${getMeta().updatedAt ?? "?"}` });
  return i.editReply({ embeds: [e] });
}

async function torneios(i) {
  const list = await getGlobalTournaments();
  if (!list.length) return i.editReply("De momento não há torneios globais ativos.");
  const shown = list.slice(0, 5);
  const top = (getMeta().decks.desafio ?? getMeta().decks["20wins"] ?? []).slice(0, 3);
  const tip = await askAI(`Torneios ativos: ${shown.map((t) => `${tourName(t)} (modo ${t.gameMode?.name ?? "?"}, máx derrotas ${t.maxLosses ?? "?"})`).join("; ")}.
Decks de desafio mais fortes do meta: ${top.map((d) => cardNames(d).join(", ")).join(" || ") || "sem dados"}.
Para cada torneio, diz em uma frase que tipo de deck usar para chegar às recompensas máximas.`);
  const e = new EmbedBuilder().setTitle("Torneios globais com recompensas").setColor(COLORS.tour)
    .setDescription(shown.map(fmtTour).join("\n\n").slice(0, 4000));
  if (tip) e.addFields({ name: "Dica da IA", value: fieldValue(tip) });
  return i.editReply({ embeds: [e] });
}

async function torneio(i) {
  const q = i.options.getString("pesquisa").trim();
  if (!q.startsWith("#") && q.length < 3) return i.editReply("Escreve pelo menos 3 letras ou uma #tag.");
  const list = q.startsWith("#") ? [await getTournament(q)] : await searchTournaments(q);
  if (!list.length) return i.editReply("Nenhum torneio encontrado.");
  const e = new EmbedBuilder().setTitle(`Torneios: ${q}`).setColor(COLORS.tour)
    .setDescription(list.slice(0, 8).map((t) => `**${tourName(t)}** (${t.tag}) – ${t.status}\n` +
      `${t.capacity ?? "?"}/${t.maxCapacity ?? "?"} jogadores · ${Math.round((t.duration ?? 0) / 60)} min · ${t.type === "open" ? "Aberto" : "Com password"}` +
      `${t.levelCap ? ` · nível ${t.levelCap}` : ""}${t.gameMode?.name ? ` · ${t.gameMode.name}` : ""}`).join("\n\n").slice(0, 4000));
  return i.editReply({ embeds: [e] });
}

async function perguntar(i) {
  const player = await getPlayer(i.options.getString("tag"));
  const tour = await resolveTournament(i.options.getString("torneio"));
  if (!tour) return i.editReply("Não encontrei esse torneio. Usa /torneios ou /torneio para ver as tags.");
  const pergunta = i.options.getString("pergunta").trim();
  const modeKey = classifyMode(tour.gameMode?.name ?? "", tourName(tour)) ?? "desafio";
  const decks = (getMeta().decks[modeKey] ?? []).slice(0, 3);
  const rewards = rewardsOf(tour).slice(0, 6).map(fmtReward).join(" | ") || "não indicadas na API";

  const answer = await askAI(`Torneio: ${tourName(tour)}. Modo: ${tour.gameMode?.name ?? MODE_LABELS[modeKey]}. Máx derrotas: ${tour.maxLosses ?? "?"}. Recompensas: ${rewards}.
Jogador: ${player.name}, ${player.trophies} troféus. Cartas mais fortes: ${strongestCards(player, 15).map((c) => `${c.name} nível ${c.lvl}${c.evo ? " EVO" : ""}`).join(", ")}.
Decks do meta para este modo: ${decks.map((d) => `${cardNames(d).join(", ")} (winrate ${winrate(d).toFixed(0)}%)`).join(" || ") || "sem dados"}.
Pergunta do jogador: ${pergunta}
Responde à pergunta de forma estratégica, usando sobretudo as cartas do jogador. Máximo 900 caracteres.`);
  if (!answer) return i.editReply("A IA não está disponível de momento. Tenta novamente daqui a pouco.");

  const e = new EmbedBuilder().setTitle(`Torneio: ${tourName(tour)}`).setColor(COLORS.tour)
    .addFields(
      { name: "Pergunta", value: fieldValue(pergunta) },
      { name: "Resposta estratégica", value: fieldValue(answer) },
    );
  return i.editReply({ embeds: [e] });
}

async function plano(i) {
  const mode = selectedMode(i);
  const player = await getPlayer(i.options.getString("tag"));
  const decks = getMeta().decks[mode] ?? [];
  if (!decks.length) return i.editReply(NO_META);

  const { names, invalid } = await parseOpponentDeck(i.options.getString("adversario"));
  if (invalid.length) return i.editReply(`Não reconheci: ${invalid.join(", ")}. Escreve os nomes das cartas como aparecem no jogo.`);
  if (names.length !== 8) return i.editReply(`O deck adversário tem de ter 8 cartas diferentes (recebi ${names.length}).`);

  const mine = buildPlayerDeck(player, mode);
  const opponent = scoreDeck(names, decks);
  const ownNames = mine.cards.map((c) => c.name);
  const hints = matchupHints(ownNames, names);
  const ai = i.commandName === "matchup" ? null : await askAI(`Modo: ${MODE_LABELS[mode]}. Deck adversário: ${names.join(", ")} (adaptação ao meta ${opponent.fit}/100).
Deck do jogador ${player.name}, montado com as cartas mais fortes dele (adaptação ao meta ${mine.fit}/100): ${mine.cards.map((c) => c.name).join(", ")}.
Decks mais fortes do meta neste modo: ${decks.slice(0, 3).map((d) => cardNames(d).join(", ")).join(" || ")}.
Pistas heurísticas locais (não garantias): ${JSON.stringify(hints)}.
Cria um plano de jogo personalizado com: 1) como abrir o jogo (elixir e posicionamento); 2) as cartas do adversário a respeitar e com que cartas do jogador as parar; 3) a condição de vitória principal; 4) 2 erros a evitar. Máximo 1000 caracteres.`);
  const fallback = "Com base apenas nas cartas identificadas: protege primeiro a tua resposta mais eficiente à condição de vitória adversária, evita gastar o feitiço pequeno sem necessidade e procura atacar quando o adversário investir demasiado elixir. Esta é uma orientação geral, não uma previsão do resultado.";
  const e = new EmbedBuilder().setTitle(`${i.commandName === "matchup" ? "Matchup" : "Plano de jogo"} · ${player.name} · ${MODE_LABELS[mode]}`).setColor(COLORS.win)
    .addFields(
      { name: `O teu deck · ${mine.fit}/100`, value: fieldValue(mine.cards.map((c) => `${c.evo ? "✨ " : ""}${c.name} (nível ${c.lvl})`).join("\n")) },
      { name: `Deck adversário · ${opponent.fit}/100`, value: fieldValue(names.join(", ")) },
      { name: "Pistas do confronto", value: fieldValue(hints.answers.map((x) => `${x.threat}: ${x.answers.length ? x.answers.join(", ") : "sem counter direto identificado no teu deck"}`).join("\n") + (hints.warnings.length ? `\n${hints.warnings.join("\n")}` : "")) },
      { name: i.commandName === "matchup" ? "Orientação de confronto" : "Plano de jogo", value: fieldValue(ai ?? fallback) },
    );
  return i.editReply({ embeds: [e] });
}

async function atualizacoes(i) {
  const month = i.options.getString("mes") ?? currentMonth();
  if (!MONTH_RE.test(month)) return i.editReply("Usa o formato AAAA-MM, por exemplo 2026-10.");
  const prev = previousMonth(month);
  const [cur, before] = await Promise.all([loadMonthSnapshots(month), loadMonthSnapshots(prev)]);
  const modes = MODES.filter((m) => cur[m]?.length);
  if (!modes.length) return i.editReply(`Não há dados guardados para ${month}.`);

  const fields = modes.map((mode) => {
    const prevList = before[mode] ?? [];
    const { top, dropped } = monthlyChanges(prevList, cur[mode]);
    const lines = top.map(({ deck, rank, status }) =>
      `**${rank}.** ${shortDeck(deck)} · ${winrate(deck).toFixed(0)}% (${deck.g} jogos) · ${prevList.length ? status : "sem comparação"}`);
    if (dropped.length) lines.push(`Saíram do top 5: ${dropped.map(shortDeck).join(" | ")}`);
    return { name: MODE_LABELS[mode], value: fieldValue(lines.join("\n")) };
  });

  const hasPrev = MODES.some((m) => before[m]?.length);
  const e = new EmbedBuilder().setTitle(`Atualizações do meta · ${month}`).setColor(COLORS.meta)
    .setDescription(hasPrev
      ? `Comparado com ${prev}.`
      : `Não há dados de ${prev} para comparar; mostra-se apenas o top de ${month}.`)
    .addFields(fields);
  return i.editReply({ embeds: [e] });
}

async function atualizar(i) {
  await refreshMeta();
  const counts = MODES.map((m) => `${MODE_LABELS[m]}: ${getMeta().decks[m]?.length ?? 0}`).join(" · ");
  return i.editReply(`Meta atualizado. ${counts}`);
}

const matchup = plano;

const handlers = { perfil, deck, meta, torneios, torneio, perguntar, plano, matchup, atualizacoes, atualizar };

export async function handleInteraction(i) {
  if (!i.isChatInputCommand()) return;
  const run = handlers[i.commandName];
  if (!run) return;
  await i.deferReply();
  try {
    await run(i);
  } catch (err) {
    console.error(`[${i.commandName}]`, err);
    await i.editReply(`Erro: ${err.message}`).catch(() => {});
  }
}

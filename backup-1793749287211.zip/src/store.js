// Persistência leve via REST: evita carregar o SDK completo do Supabase na RAM.
const TABLE_URL = () => {
  const base = process.env.SUPABASE_URL?.replace(/\/$/, "");
  return base ? `${base}/rest/v1/meta_snapshots` : null;
};

function headers(extra = {}) {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  return {
    apikey: key,
    Authorization: `Bearer ${key}`,
    "Content-Type": "application/json",
    ...extra,
  };
}

async function request(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { ...headers(), ...(options.headers ?? {}) },
    signal: AbortSignal.timeout(10_000),
  });
  if (!response.ok) {
    const detail = await response.text().catch(() => "");
    throw new Error(`Supabase respondeu ${response.status}${detail ? `: ${detail.slice(0, 180)}` : ""}`);
  }
  if (response.status === 204) return null;
  return response.json();
}

function configured() {
  return Boolean(TABLE_URL() && process.env.SUPABASE_SERVICE_ROLE_KEY);
}

export async function saveSnapshot(month, mode, decks) {
  if (!configured()) return;
  await request(`${TABLE_URL()}?on_conflict=month,mode`, {
    method: "POST",
    headers: { Prefer: "resolution=merge-duplicates,return=minimal" },
    body: JSON.stringify({ month, mode, decks, captured_at: new Date().toISOString() }),
  });
}

export async function loadLatestSnapshots() {
  if (!configured()) return { updatedAt: null, decks: {} };
  const rows = await request(`${TABLE_URL()}?select=mode,decks,captured_at&order=captured_at.desc&limit=20`);
  const decks = {};
  let updatedAt = null;
  for (const row of rows ?? []) {
    if (decks[row.mode]) continue;
    decks[row.mode] = row.decks ?? [];
    updatedAt ??= row.captured_at;
  }
  return { updatedAt, decks };
}

export async function loadMonthSnapshots(month) {
  if (!configured()) return {};
  const rows = await request(`${TABLE_URL()}?select=mode,decks&month=eq.${encodeURIComponent(month)}`);
  return Object.fromEntries((rows ?? []).map((row) => [row.mode, row.decks ?? []]));
}

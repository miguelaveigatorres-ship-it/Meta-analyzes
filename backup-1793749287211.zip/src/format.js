export const winrate = (d) => (d.g ? (d.w / d.g) * 100 : 0);
export const cardNames = (d) => d.cards.map((c) => c.name);
export const shortDeck = (d) => `${cardNames(d).slice(0, 4).join(", ")}…`;

export function fmtDeck(d) {
  const cards = d.cards.map((c) => (c.evo ? "✨" : "") + c.name).join(", ");
  return `${cards}\nWinrate: **${winrate(d).toFixed(0)}%** (${d.g} jogos)`;
}

export function crDate(s) {
  const m = /^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})/.exec(s ?? "");
  if (!m) return "?";
  const ms = Date.parse(`${m[1]}-${m[2]}-${m[3]}T${m[4]}:${m[5]}:${m[6]}Z`);
  return `<t:${Math.floor(ms / 1000)}:R>`;
}

export const tourName = (t) => t.title ?? t.name ?? "Torneio";
export const rewardsOf = (t) => [...(t.milestoneRewards ?? []), ...(t.freeTierRewards ?? [])];

export function fmtReward(r) {
  const what = r.card?.name ?? r.chest ?? r.resource ?? r.type ?? "prémio";
  return `${r.wins ?? "?"} vit.: ${r.amount ? r.amount + "× " : ""}${what}`;
}

export function fmtTour(t) {
  const rewards = rewardsOf(t).slice(0, 6).map(fmtReward).join(" | ") || "recompensas no jogo";
  return `**${tourName(t)}** · ${t.gameMode?.name ?? ""}\nTermina ${crDate(t.endTime)} · máx ${t.maxLosses ?? "?"} derrotas\nRecompensas: ${rewards}`;
}
